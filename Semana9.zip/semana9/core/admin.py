from django.contrib import admin
from .models import Carrera

admin.site.register(Carrera)
